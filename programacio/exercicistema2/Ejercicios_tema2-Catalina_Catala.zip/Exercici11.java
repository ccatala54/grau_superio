/*11- Fes un programa que sumi els números 2EF (hex) i 123 (oct)*/

public class Exercici11 {
    public static void main(String[] args) {

        int sum = 0x2EF + 0123 ;

        System.out.println("El resultado entre la suma de 2EF (hex) i 123 (oct) es : " +sum);

    }
}
