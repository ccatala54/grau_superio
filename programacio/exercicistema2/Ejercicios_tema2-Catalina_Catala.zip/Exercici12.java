/*12- Fes un programa que resti els números 11101101 (bin) i 85 (decimal)*/

public class Exercici12 {
    public static void main(String[] args) {

        int rest = 0b11101101 - 85 ;

        System.out.println("El resultado entre la resta entre 11101101 (bin) i 85 (decimal) es : " +rest);

    }
}
