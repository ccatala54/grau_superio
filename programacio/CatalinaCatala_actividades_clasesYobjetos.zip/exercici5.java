/*5- Considereu la classe següent:
public class Parts {
public static int x = 7;
public int y = 3;
}
a) Quina és la variable de classe?
b) Quina és la variable d'instància (membre)?
c) Què mostra el següent codi?
Parts a = new Parts(); Parts b = new Parts();
a.y = 5; b.y = 6;
a.x = 1; b.x = 2;
System.out.println(a.y); Sytem.out.println(b.y); System.out.println(a.x);
System.out.println(b.x);*/

public class exercici5 {

    /*
    a)En este caso, la variable de clase es x.
    b)En este caso, la variable de instancia es y.
    c)
        Valor de a.y    // Muestra 5
        Valor de b.y   // Muestra 6
        Valor de a.x   // Muestra 2
        Valor de b.x   // Muestra 2
    */
}
